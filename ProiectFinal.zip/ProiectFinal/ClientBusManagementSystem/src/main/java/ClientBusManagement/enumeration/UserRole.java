package ClientBusManagement.enumeration;

public enum UserRole {
    USER,
    ADMINISTRATOR
}
