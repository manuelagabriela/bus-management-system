package ClientBusManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientBusManagementMain {
    public static void main(String[] args) {
        SpringApplication.run(ClientBusManagementMain.class, args);
    }
}
