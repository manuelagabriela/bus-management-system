package com.VulpeManuela.BusManagement.dto;

public class GenericDTO {
    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}