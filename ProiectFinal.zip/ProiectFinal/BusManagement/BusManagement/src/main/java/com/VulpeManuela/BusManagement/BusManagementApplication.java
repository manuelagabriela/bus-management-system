package com.VulpeManuela.BusManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(BusManagementApplication.class, args);
	}

}
