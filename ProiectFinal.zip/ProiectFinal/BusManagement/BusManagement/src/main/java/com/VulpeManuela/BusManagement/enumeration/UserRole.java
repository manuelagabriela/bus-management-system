package com.VulpeManuela.BusManagement.enumeration;

public enum UserRole {
    USER,
    ADMINISTRATOR
}
